<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Custom PDF</title>
    <style>
        /* Custom CSS */
        body {
            font-family: Arial, sans-serif;
        }

        .header {
            background-color: #f0f0f0;
            padding: 20px;
            text-align: center;
        }

        .content {
            margin: 30px;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1><?php echo e($title); ?></h1>
    </div>

    <div class="content">
        <p>Hello, <?php echo e($name); ?>!</p>
        <p>This is a dynamically generated PDF.</p>
        <table border="1" cellpadding="10">
            <tr>
                <th>Key</th>
                <th>Value</th>
            </tr>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key); ?></td>
                    <td><?php echo e($value); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>

    <div class="footer">
        Generated on: <?php echo e(date('Y-m-d H:i:s')); ?>

    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\bank-account-mgt\resources\views\pdf\template.blade.php ENDPATH**/ ?>