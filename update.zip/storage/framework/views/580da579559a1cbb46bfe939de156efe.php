<html lang="en" data-mdb-theme="light">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('assets/font-awesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/mdb/css/mdb.min.css')); ?>">
    <style>
        INPUT:-webkit-autofill,
        SELECT:-webkit-autofill,
        TEXTAREA:-webkit-autofill {
            animation-name: onautofillstart;
            -webkit-background-clip: text;
            box-shadow: none !important;
            ;
            /* -webkit-box-shadow: 0 0 20px 20px #fff inset !important; */
        }
    </style>
    <title> | <?php echo e($page_title ?? 'Login'); ?></title>
    <style>
        .login-card {
            width: 500px;
        }

        @media screen and (max-width: 500px) {
            .login-card {
                width: 95%;
            }
        }
    </style>
</head>

<body class="d-flex justify-content-center align-items-center align-content-center">
    <div class="card login-card mt-5">
        <div class="card-body">
            <div class="card-header">
                <h3 class="text-center fs-3">ACCOUNTS MANAGEMENT</h3>
            </div>
            <h6 class="text-start my-4">Please Log in</h6>

            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <form id="login" method="POST" action="<?php echo e(route('authenticate')); ?>">
                <div data-mdb-input-init class="form-outline mb-4">
                    <input required autofocus type="text" name="username" id="username"
                        class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(@old('username')); ?>" />
                    <label class="form-label" for="username">Username</label>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div data-mdb-input-init class="form-outline mb-4">
                    <input required type="password" name="password" id="password"
                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                    <label class="form-label" for="password">Password</label>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php echo csrf_field(); ?>
                <button data-mdb-ripple-init data-mdb-ripple-color="light" type="submit"
                    class="btn btn-primary btn-block">
                    secure login
                </button>

            </form>
        </div>
    </div>
    <script src="<?php echo e(asset('assets/mdb/js/mdb.umd.min.js')); ?>"></script>
    
    
    <script>
        const form = document.getElementById('login');
        form && form.addEventListener('submit', function(e) {
            e.submitter.classList.add('disabled');
            return 1;
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\bank-account-mgt\resources\views/auth/login.blade.php ENDPATH**/ ?>