<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta charset="UTF-8">
    <title>Account Summary Statement</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            font-size: 24px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .summary {
            margin-bottom: 20px;
        }

        .summary p {
            margin: 5px 0;
        }

        .transactions {
            margin-top: 20px;
        }

        .footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
        }

        .page-break {
            page-break-after: always;
        }
    </style>
</head>

<body>
    <h1>Account Summary Statement - <?php echo e(strtoupper($account->name . ' (' . $account->accountLocation->name . ')')); ?></h1>
    <div class="summary">
        <p><strong>Currency:</strong> Ghana Cedi (GHS)</p>
        <p><strong>Total Credit:</strong> GHS <?php echo e(number_format($totalCredit, 2)); ?></p>
        <p><strong>Total Debit:</strong> GHS <?php echo e(number_format($totalDebit, 2)); ?></p>
        
    </div>
    <div class="transactions">
        <h2>Transaction Details
            (<?php echo e(now()->parse($startDate)->format('M d, Y')); ?> -
            <?php echo e(now()->parse($endDate)->format('M d, Y')); ?>)</h2>
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Value Date</th>
                    <th>Debit (GHS)</th>
                    <th>Credit (GHS)</th>
                    <th>Balance (GHS)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $balance = 0;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $statements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        if ($statement->entry_type_id == 'debit') {
                            // Assuming entry_type_id 2 is for debits
                            $balance -= $statement->amount;
                            $debit = $statement->amount;
                            $credit = '';
                        } else {
                            $balance += $statement->amount;
                            $debit = '';
                            $credit = $statement->amount;
                        }
                    ?>
                    <tr>
                        <td><?php echo e($statement->date->format('d-M-Y')); ?></td>
                        <td><?php echo e($statement->description); ?></td>
                        <td><?php echo e($statement->value_date->format('d-M-Y')); ?></td>
                        <td>
                            <?php if($statement->entryType->type === 'debit'): ?>
                                <?php echo e($statement->amount); ?>

                            <?php else: ?>
                                --
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($statement->entryType->type === 'credit'): ?>
                                <?php echo e($statement->amount); ?>

                            <?php else: ?>
                                --
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(number_format($balance, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="footer">
        Generated on: <?php echo e(date('Y-m-d H:i:s')); ?>

    </div>
    <div class="page-break"></div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\bank-account-mgt\resources\views/pdf/statement.blade.php ENDPATH**/ ?>