<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('assets/font-awesome/css/all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/boxicons/boxicons.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/datatables.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/select2/css/select2.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/select2/css/select2-bootstrap-5-theme.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/perfect-scroll/perfect-scrollbar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/mdb/css/mdb.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/app/main.css')); ?>" />
    <script src="<?php echo e(asset('assets/jquery/external/jquery.js')); ?>"></script>
    <title>ACCOUNTS MANAGER | <?php echo e(strtoupper($page_title) ?? 'HOME'); ?></title>
</head>
<style>
    .flex {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
</style>

<body>
    <div class="container overflow-y-auto my-5">
        <div class="row">
            <h6 class="text-center fw-bold text-uppercase">Accounts locations & balances</h6>
            <?php $__empty_1 = true; $__currentLoopData = $account_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-4 gy-2" style="min-width: 320px;">
                    <a href="<?php echo e(route('account.home', $location->id)); ?>">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title fw-bold text-start text-uppercase">
                                    <?php echo e($location->name); ?>

                                </h4>
                                
                                    <div class="text-start fs-3">
                                        <?php echo e($location->accounts->count()); ?>

                                    </div>
                                
                                <p class="card-start mb-0 pb-0 fw-semibold">Accounts Balance</p>
                                <div class="d-flex justify-content-between">
                                    <h6
                                        class="mb-0 fs-5 text-nowrap text-<?php echo e($location->accounts->sum('balance') < 0 ? 'danger' : 'success'); ?>">
                                        <i class="currency"></i>
                                        <?php echo e(number_format($location->accounts->sum('balance'), 2)); ?>

                                    </h6>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
    </div>
    <script src="<?php echo e(asset('assets/mdb/js/mdb.umd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/select2/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/perfect-scroll/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/app/color-modes.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/app/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\bank-account-mgt\resources\views/app/index.blade.php ENDPATH**/ ?>