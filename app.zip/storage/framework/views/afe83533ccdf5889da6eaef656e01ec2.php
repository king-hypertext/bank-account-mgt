<html lang="en" data-mdb-theme="light">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('assets/font-awesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/mdb/css/mdb.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/app/loader.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/jquery/jquery-ui.min.css')); ?>">
    <script src="<?php echo e(asset('assets/jquery/external/jquery.js')); ?>"></script>
    <style>
        INPUT:-webkit-autofill,
        SELECT:-webkit-autofill,
        TEXTAREA:-webkit-autofill {
            animation-name: onautofillstart;
            -webkit-background-clip: text;
            box-shadow: none !important;
            ;
            /* -webkit-box-shadow: 0 0 20px 20px #fff inset !important; */
        }

        .loader-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.7);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1096;
            overflow: hidden !important;
        }

        .loader-overlay .loader-text {
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24pt;
            text-align: center;
            margin-top: 20px;
            animation: blink 2s infinite;
            animation-timing-function: ease-in-out;
            color: #fff;
            position: absolute;
            bottom: 35%;
        }

        @keyframes blink {
            0% {
                opacity: 1;
            }

            50% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }

        @media print {
            table tr th {
                text-transform: uppercase !important;
            }
        }
    </style>
    <title>APP | <?php echo e(strtoupper($page_title) ?? 'Login'); ?></title>
    <style>
        .login-card {
            width: 500px;
        }

        @media screen and (max-width: 500px) {
            .login-card {
                width: 95%;
            }
        }
    </style>
</head>
<?php if($account_types->isEmpty()): ?>
    <script>
        window.location.reload();
    </script>
<?php endif; ?>

<body class="container">
    <div class="card mt-5">
        <div class="card-body">
            <div class="card-header border-bottom-0">
                <h3 class="text-center fs-3">CREATE LOCATION WITH ACCOUNT</h3>
            </div>
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                    <ul class="list-unstyled mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form id="account-form" action="<?php echo e(route('l.store')); ?>" method="POST">
                <div class="row mb-3">
                    <label for="location" class="col-sm-2 col-form-label text-uppercase">location</label>
                    <div class="col-sm-10">
                        <input autofocus required type="text" value="<?php echo e(@old('location')); ?>"
                            class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="location" name="location">
                        <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="account_number" class="col-sm-2 col-form-label text-uppercase">account number</label>
                    <div class="col-sm-10">
                        <input required type="text" value="<?php echo e(@old('account_number')); ?>"
                            class="form-control <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="account_number"
                            name="account_number" />
                        <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="bank_namme" class="col-sm-2 col-form-label text-uppercase">bank name</label>
                    <div class="col-sm-10">
                        <input required type="bank_namme" class="form-control <?php $__errorArgs = ['bank_namme'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="bank_namme" name="bank_name" value="<?php echo e(@old('bank_name')); ?>" />
                        <?php $__errorArgs = ['bank_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <label for="account_type" class="col-sm-2 col-form-label text-uppercase">account type</label>
                    <div class="col-auto">
                        <select required name="account_type"
                            class="form-select <?php $__errorArgs = ['account_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="account_type">
                            <?php $__empty_1 = true; $__currentLoopData = $account_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($account_type->id); ?>"><?php echo e($account_type->type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <label for="initial_amount" class="col-form-label text-uppercase col-sm-2 pt-0">initial
                        amount</label>
                    <div class="col-sm-10">
                        <input required type="text" value="0.00" onfocus="this.select()"
                            class="currencyInput form-control <?php $__errorArgs = ['initial_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="initial_amount" name="initial_amount" />
                        <?php $__errorArgs = ['initial_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <fieldset class="row mb-3">
                    <label for="account_status" class="col-form-label text-uppercase col-sm-2 pt-0">status</label>
                    <div class="col-auto">
                        <div class="mb-3">
                            <select required class="form-select <?php $__errorArgs = ['account_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="account_status" id="account_status">
                                <?php $__empty_1 = true; $__currentLoopData = $account_statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($account_status->id); ?>"><?php echo e($account_status->status); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </select>
                        </div>

                    </div>
                </fieldset>
                <fieldset class="row mb-3">
                    <label for="created_at" class="col-form-label text-uppercase col-sm-2 pt-0">date</label>
                    <div class="col-sm-10">
                        <input required type="date" value="<?php echo e(now()->format('Y-m-d')); ?>"
                            class="form-control <?php $__errorArgs = ['created_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="created_at"
                            id="created_at" placeholder="" />
                        <?php $__errorArgs = ['created_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </fieldset>
                <div class="row mb-3">
                    <label for="account_description" class="col-form-label text-uppercase col-sm-2 pt-0">notes and
                        attachments</label>
                    <div class="col-sm-10">
                        <textarea name="account_description" class="form-control <?php $__errorArgs = ['account_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="account_description" rows="3"></textarea>
                        <?php $__errorArgs = ['account_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <?php echo csrf_field(); ?>
                <div class="d-flex justify-content-end mb-3">
                    <button type="submit" class="btn btn-primary">save</button>
                </div>
            </form>
        </div>
    </div>
    <script src="<?php echo e(asset('assets/mdb/js/mdb.umd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/jquery/jquery.inputmask.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/jquery/jquery-ui.min.js')); ?>"></script>
    
    
    <script>
        const form = document.getElementById('account-form');
        form && form.addEventListener('submit', function(e) {
            e.submitter.classList.add('disabled');
            return 1;
        });
        $('.currencyInput').inputmask({
            alias: 'currency',
            prefix: '',
            rightAlign: false,
            digits: 2,
            digitsOptional: false,
            groupSeparator: ',',
            autoGroup: true,
            removeMaskOnSubmit: true,
            unmaskAsNumber: true
        });

        $('.currencyInput').keypress(function(e) {
            var charCode = (e.which) ? e.which : event.keyCode;
            if ((charCode < 48 || charCode > 57) && charCode !== 46) {
                return false;
            }
        });

        $('input[type="date"]').datepicker({
            dateFormat: 'yy-mm-dd', // Adjust the date format as needed 
            changeMonth: true, // Allows changing the month 
            changeYear: true, // Allows changing the year 
            showButtonPanel: true // Adds buttons to clear or close the datepicker 
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\bank-account-mgt\resources\views/locations/create.blade.php ENDPATH**/ ?>