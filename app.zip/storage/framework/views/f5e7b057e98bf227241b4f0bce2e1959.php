
<?php $__env->startSection('content'); ?>
    <?php use \Carbon\Carbon; ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-body-tertiary my-3 shadow-0 position-sticky"
        style="top: 60px;z-index: 50;">
        <div class="container-fluid d-flex justify-content-between">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item text-uppercase">
                        <a href="#"><?php echo e($account_location->name); ?></a>
                    </li>
                    <li class="breadcrumb-item text-uppercase">
                        <a href="#">TRASH</a>
                    </li>
                    <li class="breadcrumb-item text-uppercase active" aria-current="page">
                        <a href="#">accounts</a>
                    </li>
                </ol>
            </nav>
            <div class="d-flex">
                <a class="btn btn-info" href="<?php echo e(route('account.create', $account_location->id)); ?>">new account</a>
            </div>
        </div>
    </nav>
    <div class="card shadow-1-soft">
        <div class="card-body">
            <div class="d-flex align-items-center">
                <button id="excelButton" class="btn text-white me-1" data-mdb-ripple-init style="background-color: #438162;"
                    title="Export table to excel" type="button">
                    <i class="fas fa-print me-1"></i>
                    Excel
                </button>
                
                <button id="printButton" class="btn text-white ms-1" data-mdb-ripple-init style="background-color: #44abff;"
                    title="Click to print table" type="button">
                    <i class="fas fa-print me-1"></i>
                    print
                </button>
            </div>
            <div class="table-responsive">
                <table id="deleted-accounts-table" class="table align-middle text-uppercase">
                    <thead class="text-uppercase">
                        <tr class="border-bottom border-info">
                            <th>S/N</th>
                            <th scope="col">bank</th>
                            <th scope="col">account number</th>
                            <th scope="col">account status</th>
                            
                            <th scope="col">account type</th>
                            <th scope="col">balance</th>
                            <th scope="col">date deleted</th>
                            <th scope="col">operations</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr
                                class="<?php echo e($account->accountStatus->status == 'closed' ? 'table-danger text-danger border-danger' : ''); ?>">
                                <td>
                                    <?php echo e($loop->iteration); ?>

                                </td>
                                <td><?php echo e($account->name); ?></td>
                                <td><?php echo e($account->account_number); ?></td>
                                <td><?php echo e($account->accountStatus->status); ?></td>
                                
                                <td><?php echo e($account->accountType->type); ?></td>
                                <td class="text-<?php echo e($account->balance >= 0 ? 'success' : 'danger'); ?> fw-bold">
                                    <?php echo e(number_format($account->balance, 2, '.', ',')); ?>

                                </td>
                                <td><?php echo e(Carbon::parse($account->deleted_at)->format('Y-m-d')); ?></td>
                                <td>
                                    <button title="Restore Account" data-id="<?php echo e($account->id); ?>"
                                        data-url="<?php echo e(route('account.restore', [$account_location->id, $account->id])); ?>"
                                        class="btn btn- p-1 mx-1 restore-account">
                                        <i class="fas text-danger fa-recycle"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </tbody>                    
                </table>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $('button.restore-account').click(function() {
                const id = $(this).data('id');
                const url = $(this).data('url');
                const $button = $(this);
                const $loader = $('.loader-overlay');
                if (!confirm('Confirm restore account')) {
                    return false;
                }
                $.ajax({
                    url,
                    method: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    beforeSend: function() {
                        $button.prop('disabled', true);
                        $loader.show().find('.loader-text').text('Deleting...');
                    },
                    success: function(response) {
                        if (response.success) {
                            window.open(response.url, '_self');
                        } else {
                            alert(`Failed to restore account: ${response.message}`);
                        }
                        $button.prop('disabled', false);
                        $loader.hide();
                    },
                    error: function(xhr, status, error) {
                        alert(`An error occurred: ${xhr.responseText}`);
                        $button.prop('disabled', false);
                        $loader.hide();
                    }
                });
            });
            const ACCOUNTS_TABLE = new DataTable('#deleted-accounts-table', {
                responsive: true,
                order: [
                    false
                ],
                columnDefs: [{
                        targets: [7],
                        orderable: false
                    },
                ],
                // dom: '<"row"<"col-md-4"l><"col-md-4"B><"col-md-4"f>>rt<"row"<"col-md-4"i><"col-md-4"p><"col-md-4"n>>',
                // buttons: ['copy', 'excel', 'pdf', 'csv', 'print'],
                // footerCallback: function(row, data, start, end, display) {
                //     var api = this.api(),
                //         data;
                //     var intVal = function(i) {
                //         if (typeof i === 'string') {
                //             return i.replace(/[\$,]/g, '') * 1.00;
                //         } else if (typeof i === 'number') {
                //             return i;
                //         }
                //     };
                //     var total = api.column(6).data().reduce(function(a, b) {
                //         return intVal(a) + intVal(b);
                //     }, 0.00);
                //     var formatter = new Intl.NumberFormat('en-US', {
                //         style: 'currency',
                //         currency: 'GHS',
                //     });
                //     var pageTotal = api.column(6, {
                //         page: 'current'
                //     }).data().reduce(function(a, b) {
                //         return intVal(a) + intVal(b);
                //     }, 0.00);
                //     $(api.column(6).footer()).addClass('fw-semibold').html(formatter.format(pageTotal));
                // },
                buttons: [{
                        extend: 'excel',
                        title: '<?php echo e(strtoupper($account_location->name)); ?> DELETED ACCOUNTS',
                        filename: 'bank-list.excel',
                        text: '<i class="fas fa-print me-1"></i> excel',
                        className: 'btn text-white ms-1',
                        message: 'Printed on ' + new Date().toLocaleString(),
                        attr: {
                            "style": 'background-color: #438162;color: #fff',
                            "data-mdb-ripple-init": '',
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7]
                        }
                    },
                    {
                        extend: 'pdf',
                        title: '<?php echo e(strtoupper($account_location->name)); ?> DELETED ACCOUNTS',
                        filename: 'bank-list.pdf',
                        orientation: 'portrait',
                        pageSize: 'A4',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7],
                        },
                        text: '<i class="fas fa-print me-1"></i> pdf',
                        className: 'btn text-white ms-1',
                        message: 'Printed on ' + new Date().toLocaleString(),
                        attr: {
                            "style": 'background-color: #ee4a60;color: #fff',
                            "data-mdb-ripple-init": '',
                        }
                    },
                    {
                        extend: 'print',
                        text: '<i class="fas fa-print me-1"></i> print',
                        className: 'btn text-white ms-1',
                        title: '<span class="text-uppercase text-center"> <?php echo e($account_location->name); ?> DELETED ACCOUNTS</span>',
                        pageSize: 'A4',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7],
                        },
                        orientation: 'portrait',
                        message: 'Printed on ' + new Date().toLocaleString(),
                        attr: {
                            "style": 'background-color: #44abff;color: #fff',
                            "data-mdb-ripple-init": '',
                        }
                    }
                ],
                language: {
                    paginate: {
                        first: 'First',
                        previous: 'Prev',
                        next: 'Next',
                        last: 'Last',
                    }
                }
            });
            $('#pdfButton').on('click', function() {
                ACCOUNTS_TABLE.button(1).trigger();
            });
            $('#excelButton').on('click', function() {
                ACCOUNTS_TABLE.buttons(0).trigger();
            });
            $('#printButton').on('click', function() {
                ACCOUNTS_TABLE.button(2).trigger();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bank-account-mgt\resources\views\trash\index.blade.php ENDPATH**/ ?>